/// <reference types="../src/module" />
/// <reference types="@nuxt/eslint" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="nuxt-mcp" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../../node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="C:/devs/nuxt-feathers-zod/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}

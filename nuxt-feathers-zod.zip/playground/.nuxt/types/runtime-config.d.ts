import { RuntimeConfig as UserRuntimeConfig, PublicRuntimeConfig as UserPublicRuntimeConfig } from 'nuxt/schema'
  interface SharedRuntimeConfig {
   app: {
      buildId: string,

      baseURL: string,

      buildAssetsDir: string,

      cdnURL: string,
   },

   nitro: {
      envPrefix: string,
   },

   _feathers: {
      auth: {
         entity: string,

         entityClass: string,

         service: string,

         secret: string,

         authStrategies: Array<string>,

         jwtOptions: {
            header: {
               alg: string,

               typ: string,
            },

            audience: string,

            algorithm: string,

            expiresIn: string,
         },

         local: {
            usernameField: string,

            passwordField: string,
         },

         client: {
            storageKey: string,
         },

         entityImport: {
            name: string,

            as: string,

            from: string,

            type: boolean,
         },
      },
   },
  }
  interface SharedPublicRuntimeConfig {
   _feathers: {
      transports: {
         rest: {
            path: string,

            framework: string,
         },

         websocket: {
            path: string,

            connectTimeout: number,
         },
      },

      auth: {
         authStrategies: Array<string>,

         servicePath: string,

         entityKey: string,

         entityClass: string,

         client: {
            storageKey: string,
         },
      },

      pinia: {
         storesDirs: Array<string>,

         idField: string,

         services: {
            mongos: {
               idField: string,
            },
         },
      },
   },
  }
declare module '@nuxt/schema' {
  interface RuntimeConfig extends UserRuntimeConfig {}
  interface PublicRuntimeConfig extends UserPublicRuntimeConfig {}
}
declare module 'nuxt/schema' {
  interface RuntimeConfig extends SharedRuntimeConfig {}
  interface PublicRuntimeConfig extends SharedPublicRuntimeConfig {}
}
declare module 'vue' {
        interface ComponentCustomProperties {
          $config: UserRuntimeConfig
        }
      }
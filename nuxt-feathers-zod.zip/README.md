# nuxt-feathers-zod

[![npm version][npm-version-src]][npm-version-href]
[![npm downloads][npm-downloads-src]][npm-downloads-href]
[![License][license-src]][license-href]
[![code style][code-style-src]][code-style-href]

Feathers API integration for Nuxt

[🏀 Online playground](https://stackblitz.com/github/gabortorma/nuxt-feathers-zod?file=playground%2Fapp.vue)

## Install

```bash
pnpm install add -D nuxt-feathers-zod
```

## Usage

### Nuxt

Add the plugin to your `nuxt.config.js`:

```ts
export default defineNuxtConfig({
  modules: [
    'nuxt-feathers-zod'
  ],

  feathers: {
    // your module options
  }
})
```

<!-- Badges -->

[npm-version-src]: https://img.shields.io/npm/v/@gabortorma/nuxt-feathers-zod/latest.svg?style=flat&colorA=18181B&colorB=28CF8D
[npm-version-href]: https://npmjs.com/package/@gabortorma/nuxt-feathers-zod
[npm-downloads-src]: https://img.shields.io/npm/dm/@gabortorma/nuxt-feathers-zod.svg?style=flat&colorA=18181B&colorB=28CF8D
[npm-downloads-href]: https://npmjs.com/package/@gabortorma/nuxt-feathers-zod
[license-src]: https://img.shields.io/npm/l/@gabortorma/nuxt-feathers-zod.svg?style=flat&colorA=18181B&colorB=28CF8D
[license-href]: https://npmjs.com/package/@gabortorma/nuxt-feathers-zod
[code-style-src]: https://antfu.me/badge-code-style.svg
[code-style-href]: https://github.com/gabortorma/antfu-eslint-config
